package test

import (
	"fmt"
	"io/ioutil"
	"log"

	"testing"

	"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
)

type YamlConfig struct {
	Rsg struct {
		Name     string `yaml:"name"`
		Location string `yaml:"location"`
	} `yaml:"rsg"`
	Vnet struct {
		Name         string   `yaml:"name"`
		AddressSpace []string `yaml:"address_space"`
		Subnet       struct {
			Name            string   `yaml:"name"`
			AddressPrefixes []string `yaml:"address_prefixes"`
		} `yaml:"subnet"`
	} `yaml:"vnet"`
	Kv struct {
		Name              string `yaml:"name"`
		ResourceGroupName string `yaml:"resource_group_name"`
		Key               string `yaml:"key"`
	} `yaml:"kv"`
	Mid struct {
		Name string `yaml:"name"`
	} `yaml:"mid"`
	Aks struct {
		Name   string `yaml:"name"`
		AcrID  string `yaml:"acr_id"`
		Config struct {
			RbacAadManaged               bool          `yaml:"rbac_aad_managed"`
			EnableRoleBasedAccessControl bool          `yaml:"enable_role_based_access_control"`
			AdminUsername                string        `yaml:"admin_username"`
			RbacAadAdminGroupObjectIds   []interface{} `yaml:"rbac_aad_admin_group_object_ids"`
			EnableHTTPApplicationRouting bool          `yaml:"enable_http_application_routing"`
			EnableAzurePolicy            bool          `yaml:"enable_azure_policy"`
			PrivateClusterEnabled        bool          `yaml:"private_cluster_enabled"`
			AksVersion                   string        `yaml:"aks_version"`
			SkuTier                      string        `yaml:"sku_tier"`
			DefaultNodePool              struct {
				OsDiskSizeGb         int           `yaml:"os_disk_size_gb"`
				EnableAzurePolicy    bool          `yaml:"enable_azure_policy"`
				EnableHostEncryption bool          `yaml:"enable_host_encryption"`
				SkuTier              string        `yaml:"sku_tier"`
				EnableNodePublicIP   bool          `yaml:"enable_node_public_ip"`
				EnableAutoScaling    bool          `yaml:"enable_auto_scaling"`
				AgentsSize           string        `yaml:"agents_size"`
				AgentsMinCount       int           `yaml:"agents_min_count"`
				AgentsMaxCount       int           `yaml:"agents_max_count"`
				AgentsCount          interface{}   `yaml:"agents_count"`
				AgentsMaxPods        int           `yaml:"agents_max_pods"`
				AgentsPoolName       string        `yaml:"agents_pool_name"`
				AgentsType           string        `yaml:"agents_type"`
				NodeTaints           []interface{} `yaml:"node_taints"`
				NodeLabels           struct {
					NodeType string `yaml:"nodeType"`
				} `yaml:"node_labels"`
			} `yaml:"default_node_pool"`
		} `yaml:"config"`
		NodesPools struct {
			Pool01 struct {
				OsDiskSizeGb         int           `yaml:"os_disk_size_gb"`
				EnableAzurePolicy    bool          `yaml:"enable_azure_policy"`
				EnableHostEncryption bool          `yaml:"enable_host_encryption"`
				SkuTier              string        `yaml:"sku_tier"`
				EnableNodePublicIP   bool          `yaml:"enable_node_public_ip"`
				EnableAutoScaling    bool          `yaml:"enable_auto_scaling"`
				AgentsSize           string        `yaml:"agents_size"`
				AgentsMinCount       int           `yaml:"agents_min_count"`
				AgentsMaxCount       int           `yaml:"agents_max_count"`
				AgentsCount          interface{}   `yaml:"agents_count"`
				AgentsMaxPods        int           `yaml:"agents_max_pods"`
				AgentsType           string        `yaml:"agents_type"`
				NodeTaints           []interface{} `yaml:"node_taints"`
				NodeLabels           struct {
					App      string `yaml:"app"`
					NodeType string `yaml:"nodeType"`
				} `yaml:"node_labels"`
			} `yaml:"pool01"`
		} `yaml:"nodes_pools"`
	} `yaml:"aks"`
}


func TestTerraformAKSWithNoCMEK(t *testing.T) {
	t.Parallel()

	// subscriptionID is overridden by the environment variable "ARM_SUBSCRIPTION_ID"
	subscriptionID := "785240be-8d39-4686-b73e-365e2efc68c2"
	modulePath := "../examples/aks_with_cmek"

	data_file, err := ioutil.ReadFile(fmt.Sprintf("%s/%s", modulePath, "aks.yaml"))
	if err != nil {
		log.Fatal(err)
	}

	var intput_data YamlConfig
	error := yaml.Unmarshal(data_file, &intput_data)
	if error != nil {
		log.Fatal(err)
	}

	// website::tag::1:: Configure Terraform setting up a path to Terraform code.
	terraformOptions := &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: modulePath,

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{},
	}

	// website::tag::4:: At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// website::tag::2:: Run `terraform init` and `terraform apply`. Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// website::tag::3:: Verify mysql properties and ensure it matches.
	cluster, err := azure.GetManagedClusterE(t, intput_data.Rsg.Name, intput_data.Aks.Name, subscriptionID)
	require.NoError(t, err)
	assert.NotNil(t, cluster)
}

func TestTerraformAKSWithCMEK(t *testing.T) {
	t.Parallel()

	// subscriptionID is overridden by the environment variable "ARM_SUBSCRIPTION_ID"
	subscriptionID := "785240be-8d39-4686-b73e-365e2efc68c2"
	modulePath := "../examples/aks_with_no_cmek"

	data_file, err := ioutil.ReadFile(fmt.Sprintf("%s/%s", modulePath, "aks.yaml"))
	if err != nil {
		log.Fatal(err)
	}

	var intput_data YamlConfig
	error := yaml.Unmarshal(data_file, &intput_data)
	if error != nil {
		log.Fatal(err)
	}

	// website::tag::1:: Configure Terraform setting up a path to Terraform code.
	terraformOptions := &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: modulePath,

		// Variables to pass to our Terraform code using -var options
		Vars: map[string]interface{}{},
	}

	// website::tag::4:: At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// website::tag::2:: Run `terraform init` and `terraform apply`. Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// website::tag::3:: Verify mysql properties and ensure it matches.
	cluster, err := azure.GetManagedClusterE(t, intput_data.Rsg.Name, intput_data.Aks.Name, subscriptionID)
	require.NoError(t, err)
	assert.NotNil(t, cluster)
}
